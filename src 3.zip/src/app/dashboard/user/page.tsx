"use client";

import { useUserPanel } from "@/components/user/useUserPanel";
import UserProfileSection from "@/components/user/UserProfileSection";

export default function UserPage() {
  const {
    t,
    clonacionVideos,
    handleUpload,
    handleDelete,
    uploading,
    progress,
  } = useUserPanel();

  return (
    <div className="space-y-8">
      <UserProfileSection t={t} />
    </div>
  );
}
