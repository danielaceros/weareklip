import LipsyncPage from "@/components/video/LipsyncCreatePage";

export default function Page() {
  return <LipsyncPage />;
}
