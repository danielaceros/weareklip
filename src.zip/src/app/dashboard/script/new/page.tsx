import ScriptCreatorContainer from "@/components/script/ScriptCreatorContainer";

export default function Page() {
  return <ScriptCreatorContainer />;
}
