import VoicesListContainer from "@/components/voice/VoicesListContainer";

export default function Page() {
  return <VoicesListContainer />;
}
