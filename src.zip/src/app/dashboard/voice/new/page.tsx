import NewVoiceContainer from "@/components/voice/NewVoiceContainer";

export default function Page() {
  return <NewVoiceContainer />;
}
