import IdeasViralesPage from "@/components/ideas/IdeasViralesPage";

export default function Page() {
  return <IdeasViralesPage />;
}
