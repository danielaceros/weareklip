(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_2087bc5f._.js",
  "static/chunks/src_eec443db._.js"
],
    source: "dynamic"
});
