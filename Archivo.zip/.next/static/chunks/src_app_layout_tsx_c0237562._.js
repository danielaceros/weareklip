(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_45c72bad._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_@firebase_storage_dist_index_esm2017_b3a08d2a.js",
  "static/chunks/node_modules_1534d457._.js",
  "static/chunks/src_0c24af8b._.js"
],
    source: "dynamic"
});
