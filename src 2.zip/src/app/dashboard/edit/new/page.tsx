import CreateVideoPage from "@/components/edit/CreateVideoPage";

export default function EditPage() {
  return <CreateVideoPage />;
}
