import VideosPage from "@/components/edit/VideosPage";

export default function EditPage() {
  return <VideosPage />;
}
