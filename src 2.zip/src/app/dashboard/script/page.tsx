import ScriptsContainer from "@/components/script/ScriptsContainer";

export default function Page() {
  return <ScriptsContainer />;
}
