import LipsyncVideosPage from "@/components/video/LipsyncVideosPage";

export default function Page() {
  return <LipsyncVideosPage />;
}
