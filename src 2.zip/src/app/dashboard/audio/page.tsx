import AudiosContainer from "@/components/audio/AudiosContainer";

export default function Page() {
  return <AudiosContainer />;
}
