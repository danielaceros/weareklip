import AudioCreatorContainer from "@/components/audio/AudioCreatorContainer";

export default function Page() {
  return <AudioCreatorContainer />;
}
